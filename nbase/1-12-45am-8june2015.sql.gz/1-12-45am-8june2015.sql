-- MySQL dump 10.13  Distrib 5.6.13, for Linux (x86_64)
--
-- Host: localhost    Database: banoful
-- ------------------------------------------------------
-- Server version	5.6.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'sweets','Order Bonoful Sweets online and send gift to Bangladesh. Bonoful sweets are ideal to congratulate anyone on any special occasion. We deliver Bonoful sweets to all cities of Bangladesh.'),(2,' cakes','Bonoful is the most famous cake and pastry supplier in Bangladesh,and now we are offering our products and services in Dhaka as well. Order mouth-watering cakes with special designs from Well Food online and surprise your loved-one on their birthday, anniversary, wedding and any other gift occasions.\r\n'),(3,' biscuits','  Order Bonoful biscuits online.Bonoful biscuits are ideal for any special family  occasion. We deliver Bonoful biscuits to all cities of Bangladesh. '),(4,' chanachur','  Order Bonoful chanachur online.Bonoful chanachur are ideal for any special family  occasion. We deliver Bonoful chanachur to all cities of Bangladesh. '),(5,' fast food','Fast foods are characterized as quick, easily accessible and cheap alternatives to home-cooked meals and responded to growing public awareness about nutrition by offering some food that is lower in fat and calories.'),(6,' bread','We provide different categories of bread,usually different taste.some of these are slice bread,patato bon,fruit bon,dark bread,special bon.'),(7,' semai','Bonoful Special Lascha Semai.\r\nEver Fresh With Real Taste.Please type the quantity of products you want to buy and click on \"add to cart\" button below.'),(8,'noodles','Bonoful Special noodles.Tasty and Delicious.Please type the quantity of products you want to buy and click on \"add to cart\" button below.'),(9,' other desserts','The course usually consists of sweet foods,but may include other items.we provide different categories of desserts such as lassi,faluda,doi,drinks,doi etc.');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'suborna','suborna@gmail.com','How to buy from your site?'),(2,'sanjida','sanjida@gmail.com','I want to buy noodles.'),(3,' sanjidaa',' s@gmail.com',' fdgftt'),(4,' nabanita',' naba@gmil.com',' I want to get 1kg kachagolla at my home. Can you help me?');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` int(50) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `birthday` date NOT NULL,
  `password` varchar(255) NOT NULL,
  `sex` varchar(6) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'sanjida','sanjida1024@gmail.com','hatiya','1992-01-01','501cc81c72e68c7d13d7e06d84130d81','female'),(2,'suborna','subornamoon1992@gmail.com','hatiya','1990-01-01','4ef7e70c02983547ac802a38a673110e','female');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `orderlist` text NOT NULL,
  `customer_id` int(10) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `shipment_address` text NOT NULL,
  `shipment_done` int(10) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,'fsddsg',4,'fs','fdg',4,'2015-05-07 00:00:00'),(2,'',4,'paypal','comilla',0,'2015-05-07 00:00:00'),(3,'',4,'paypal','comilla',0,'2015-05-07 00:00:00'),(4,'',4,'paypal','comilla',0,'2015-05-07 00:00:00'),(5,'',4,'paypal','comilla',0,'2015-05-07 00:00:00'),(6,'',4,'paypal','comilla',0,'2015-05-07 00:00:00'),(7,'<div>Product Code2534hu and Quantity 1</div><br>',37,'paypal','comilla',0,'2015-05-07 00:00:00'),(8,'<div>Product CodePD1001 and Quantity 1</div><br><div>Product CodePD1003 and Quantity 1</div><br>',1,'paypal','comilla',0,'2015-05-07 00:00:00'),(9,'<div>Product CodePD3001 and Quantity 1</div><br><div>Product CodePD3005 and Quantity 1</div><br>',1,'paypal','comilla',0,'2015-05-07 00:00:00');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(60) NOT NULL,
  `product_code` varchar(60) NOT NULL,
  `product_desc` text NOT NULL,
  `product_img_name` varchar(60) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Blackberry','PD1001',' Blackberry from Bonoful sweets. Price is shown for 1kg of this sweet and you can increase the quantity to order more.','blackberry.jpg',400.00,'1 '),(2,'Blackjam','PD1002','Blackjam from Bonoful sweets. Price is shown for 1kg of this sweet and you can increase the quantity to order more.','blackjaam.jpg',400.00,'1 '),(3,'Chamcham','PD1003','Chamcham from Bonoful sweets. Price is shown for 1kg of this sweet and you can increase the quantity to order more.','chamcham.jpg',300.00,'1 '),(4,'Kacha Golla','PD1004','Kachagolla from Bonoful sweets. Price is shown for 1kg of this sweet and you can increase the quantity to order more.','kachagolla.jpg',300.00,'1 '),(5,'Mawa Laddu','PD1005','Mawa Laddu from Bonoful sweets. Price is shown for 1kg of this sweet and you can increase the quantity to order more.','MawaLadduBonoful.jpg',600.00,'1 '),(6,'Sondesh','PD1006','Sondesh from Bonoful sweets. Price is shown for 1kg of this sweet and you can increase the quantity to order more.','shondesh.jpg',600.00,'1 '),(7,'Katari Vogh','PD1007','Katari vough from Bonoful sweets. Price is shown for 1kg of this sweet and you can increase the quantity to order more. ','katarivogh.jpg',350.00,'1 '),(8,'Birthday Cake','PD2001','Chocolate degert cake. Price is shown for small size cake (half Kg) but you can order Medium, Big size or 2kg cake by selecting cake size option above before adding this product to your shopping cart.','birthday cake.jpg',350.00,'2 '),(10,'Doriman cake','PD2002','Kids are now dreaming about a cake with Doraemon cartoon on their birthday.This cake with special design starts from 1.5 kg and you can increase it up to 4 kg. Price is shown for 1.5 kg Vanilla flavoured Dorimon cake.','doriman.jpg',400.00,'2 '),(11,'Slice Cake','PD2003','slice cake is ordered as per piece.you can order more than 1piece as your wish.','slice cake1.jpg',30.00,'2 '),(12,'Chocolate Rice Cake','PD2004','Special chocolate rice cake by Bonoful for birthday, anniversary and other gift occasions in Bangladesh. Price is shown for small size cake (half Kg) but you can order Medium, Big size or 2kg cake by selecting cake size option above before adding this product to your shopping cart.','thumb_MrBaker_04.jpg',350.00,'2 '),(13,'Vanilla Cake','PD2005','Vanilla cake.Price is shown for small size cake (half Kg) but you can order Medium, Big size or 2kg cake by selecting cake size option above before adding this product to your shopping cart.','vanilla cake.jpg',350.00,'2 '),(14,'Choko Meri Biscuit','PD3001','Bonoful Choko Meri Biscuit from Bonoful sweets. Price is shown for 1 packet of this biscuit and you can increase the quantity to order more.','choko meri.jpg',50.00,'3 '),(15,'Bonoful Crispy Biscuit','PD3002','Bonoful Crispy Biscuit from Bonoful sweets & Co. Price is shown for 1 packet of this biscuit and you can increase the quantity to order more.','crispy biscuit.jpg',55.00,'3 '),(16,'Bonoful Dia Gold Biscuit','PD3003','Bonoful Dia Gold Biscuit from Bonoful sweets & Co. Price is shown for 1 packet of this biscuit and you can increase the quantity to order more.','dia gold.jpg',60.00,'3 '),(17,'Bonoful Mango Biscuit','PD3004','Bonoful Mango Biscuit from Bonoful sweets & Co. Price is shown for 1 packet of this biscuit and you can increase the quantity to order more.','mango biscuit.jpg',40.00,'3 '),(18,'Bonoful Special Bela Biscuit','PD3005','Bonoful Special Bela Biscuit from Bonoful sweets & Co. Price is shown for 1 packet of this biscuit and you can increase the quantity to order more.','special bela.jpg',66.00,'3 '),(19,'Bonoful Special Toast Biscuit','PD3006','Bonoful Special Toast Biscuit from Bonoful sweets & Co. Price is shown for 1 packet of this biscuit and you can increase the quantity to order more.','special toast.jpg',60.00,'3 '),(20,'Bonoful Canachur','PD4001','Testy 350gm Bonoful Chanachur.Price is shown for 1 packet of this canachur and you can increase the quantity to order more. ','bonofulCanachur.jpg',85.00,'4 '),(21,'Bonoful Crispy Canachur','PD4002','Testy 350gm Bonoful Crispy Chanachur.Price is shown for 1 packet of this canachur and you can increase the quantity to order more. ','crispyCanachur.jpg',85.00,'4 '),(22,'Bonoful Royal Canachur','PD4003','Testy 350gm Bonoful Royal Chanachur.Price is shown for 1 packet of this canachur and you can increase the quantity to order more. ','royalCanachur.jpg ',90.00,'4 '),(23,'Bonoful Special Canachur','PD4004','Testy 350gm Bonoful Special Chanachur.Price is shown for 1 packet of this canachur and you can increase the quantity to order more. ','specialCanachur.jpg',85.00,'4 '),(24,'Burger','PD5001','Testy and spicy burger from Bonoful food products.You can increase the number of people and make it a bigger package.','burger.jpg',40.00,'5 '),(25,'Pizza','PD5002','Testy and spicy pizza from Bonoful food products.You can increase the number of people and make it a bigger package.','pizza.jpg',80.00,'5 '),(26,'Chicken Roll','PD5003','Testy and spicy Chicken Roll from Bonoful food products.You can increase the number of people and make it a bigger package.','roll.jpg',15.00,'5 '),(27,'Samussa','PD5004','Testy and spicy Samussa from Bonoful food products.You can increase the number of people and make it a bigger package.','samussa.jpg',6.00,'5 '),(28,'Singara','PD5005','Testy and spicy Singara from Bonoful food products.You can increase the number of people and make it a bigger package.','singara.jpg',6.00,'5 '),(29,'Bonoful Special Bon','PD6001','Bonoful special bon(2pcs).Price is shown for 1 packet of this bread and you can increase the quantity to order more.','bon.jpg',12.00,'6 '),(30,'Bonoful Dark Bread','PD6002','Bonoful Dark Bread.Price is shown for 1 packet of this bread and you can increase the quantity to order more.','dark bread.JPG ',30.00,'6 '),(31,'Bonoful Fruit Bon','PD6003','Bonoful Fruit Bon.Price is shown for 1 packet of this bread and you can increase the quantity to order more.','fruit bon.jpg ',20.00,'6 '),(32,'Bonoful Potato Bon','PD6004','Bonoful Potato Bon.Price is shown for 1 packet of this bread and you can increase the quantity to order more.','patato bon.jpg ',50.00,'6 '),(33,'Bonoful Special  Bread','PD6005','Bonoful Special Bread.Price is shown for 1 packet of this bread and you can increase the quantity to order more. ','specialBread.jpg ',30.00,'6 ');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-06-07 18:45:44
